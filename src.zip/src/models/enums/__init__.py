from .ResponseEnums import ResponseSignal
